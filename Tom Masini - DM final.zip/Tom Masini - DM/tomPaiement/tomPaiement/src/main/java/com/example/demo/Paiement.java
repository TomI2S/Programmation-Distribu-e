package com.example.demo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@ToString
public class Paiement {
    @javax.persistence.Id
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Integer productId;

    private Date datePaiement;

    private Integer quantite;

    private Boolean payee;

    public Paiement(Long id, Integer productId, Date datePaiement, Integer quantite, Boolean payee) {
        this.id = id;
        this.productId = productId;
        this.datePaiement = datePaiement;
        this.quantite = quantite;
        this.payee = payee;
    }

    public Long getId() {
        return id;
    }

    public Integer getProductId() {
        return productId;
    }

    public Date getDatePaiement() {
        return datePaiement;
    }

    public Integer getQuantite() {
        return quantite;
    }

    public Boolean getPayee() {
        return payee;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public void setDatePaiement(Date datePaiement) {
        this.datePaiement = datePaiement;
    }

    public void setQuantite(Integer quantite) {
        this.quantite = quantite;
    }

    public void setPayee(Boolean payee) {
        this.payee = payee;
    }

    @Override
    public String toString() {
        return "Paiement{" +
                "id=" + id +
                ", productId=" + productId +
                ", datePaiement=" + datePaiement +
                ", quantite=" + quantite +
                ", payee=" + payee +
                '}';
    }
}
