package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class tomPaiementController {
    @Autowired
    tomPaiementRepository paiementDao;

    @PostMapping(value = "/paiements")
    public ResponseEntity<Paiement> ajouterPaiement(@RequestBody Paiement paiement){

        Paiement nouveauPaiement = paiementDao.save(paiement);

        return new ResponseEntity<Paiement>(paiement, HttpStatus.CREATED);
    }

    @GetMapping(value = "/paiements/{id}")
    public Optional<Paiement> recupererUnPaiement(@PathVariable Long id){

        Optional<Paiement> paiement = paiementDao.findById(id);

        return paiement;
    }
}
